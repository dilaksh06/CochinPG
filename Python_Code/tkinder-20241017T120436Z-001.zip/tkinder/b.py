import tkinter as tk

# Create a function to handle the login button click event
def login():
    username = username_entry.get()
    password = password_entry.get()

    if username == "user1" and password == "abcd123":
        login_status.config(text="Login successful", fg="green")
    else:
        login_status.config(text="Login failed. Try again.", fg="red")

# Create the main Tkinter window
parent = tk.Tk()
parent.geometry("1000x1000")
parent.configure(background="#f2ffe6")
parent.title("Login Form")

# Create labels and Entry widgets for username and password
username_label = tk.Label(parent, text="Username:",     
                 bg="#f2ffe6",                       
                 font=("Arial", 14, "bold"),   
                 fg="#66cc00",             
                 wraplength=250 )
                 
password_label = tk.Label(parent, text="Password:",
bg="#f2ffe6",                       
                 font=("Arial", 14, "bold"),   
                 fg="#66cc00",             
                 wraplength=250)
                 
username_entry = tk.Entry(parent)
password_entry = tk.Entry(parent, show="*")  # Show '*' for password entry

# Create a Login button
login_button = tk.Button(parent, text="Login", command=login,

                   activebackground="#2db300", 
                   activeforeground="white",
                   anchor="center",
                 
                   bg="#79ff4d",
                   cursor="hand2",
                   disabledforeground="gray",
                   fg="black",
                   font=("Arial"),
                 
                   highlightbackground="black",
                   highlightcolor="green",
                  
                   justify="center",
                   overrelief="raised",
                
                

)

# Create a label to display login status
login_status = tk.Label(parent, text="", fg="black")


# Use the Grid geometry manager to arrange widgets
username_label.place(x=600,y=300)

username_entry.place(x=700,y=300)

password_label.place(x=600,y=350)
password_entry.place(x=700,y=350)

login_button.place(x=750,y=400)
login_status.grid(row=3, column=0, columnspan=2, padx=10, pady=5)
# Run the Tkinter main loop
parent.mainloop()

